package com.mycompany.treemain;

public class Node {
    private int deger;
    private Node sol;
    private Node sağ;
    private Node parent;
    public int yer;
    public Node() {
        
    }
    
    public Node(int deger, Node parent) {
        this.deger = deger;
        this.parent = parent;
    }   

    public int getValue() {
        return deger;
    }

    public Node getLeft() {
        return sol;
    }

    public Node getRight() {
        return sağ;
    }

    public Node getParent() {
        return parent;
    }

    public void setValue(int deger) {
        this.deger = deger;
    }

    public void setLeft(Node sol) {
        this.sol = sol;
    }

    public void setRight(Node sağ) {
        this.sağ = sağ;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }
    
}